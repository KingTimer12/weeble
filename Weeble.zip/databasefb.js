const {initializeApp} = require('firebase/app')
const {getDatabase, ref, child, get, onValue, set} = require('firebase/database')
const firebaseConfig = {
    apiKey: "AIzaSyBoO1DQI9xAmfOPmbyYvGSdgKcz2--EHBY",
    authDomain: "weeble-2cdc0.firebaseapp.com",
    databaseURL: "https://weeble-2cdc0-default-rtdb.firebaseio.com",
    projectId: "weeble-2cdc0",
    storageBucket: "weeble-2cdc0.appspot.com",
    messagingSenderId: "1095655962632",
    appId: "1:1095655962632:web:554560721eb495750b79bd",
    measurementId: "G-FCN3QX56RF"
};
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

exports.db = () => {
    return database;
}